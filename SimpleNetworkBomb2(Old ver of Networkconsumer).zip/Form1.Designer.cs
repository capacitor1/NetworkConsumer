﻿namespace SimpleNetworkBomb
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            Total = new Label();
            Run = new Button();
            Stop = new Button();
            URL = new ComboBox();
            label1 = new Label();
            Speed = new Label();
            label5 = new Label();
            Thread = new NumericUpDown();
            groupBox1 = new GroupBox();
            ThreadNow = new Label();
            label3 = new Label();
            groupBox2 = new GroupBox();
            label4 = new Label();
            groupBox3 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)Thread).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 19);
            label2.Name = "label2";
            label2.Size = new Size(56, 17);
            label2.TabIndex = 2;
            label2.Text = "已消耗：";
            // 
            // Total
            // 
            Total.Location = new Point(68, 19);
            Total.Name = "Total";
            Total.Size = new Size(219, 17);
            Total.TabIndex = 3;
            Total.Text = "0 B";
            Total.TextAlign = ContentAlignment.MiddleRight;
            // 
            // Run
            // 
            Run.Location = new Point(164, 33);
            Run.Name = "Run";
            Run.Size = new Size(75, 23);
            Run.TabIndex = 4;
            Run.Text = "开始";
            Run.UseVisualStyleBackColor = true;
            Run.Click += button1_Click;
            // 
            // Stop
            // 
            Stop.Location = new Point(245, 33);
            Stop.Name = "Stop";
            Stop.Size = new Size(75, 23);
            Stop.TabIndex = 5;
            Stop.Text = "停止";
            Stop.UseVisualStyleBackColor = true;
            Stop.Click += button2_Click;
            // 
            // URL
            // 
            URL.FormattingEnabled = true;
            URL.Location = new Point(80, 17);
            URL.Name = "URL";
            URL.Size = new Size(538, 25);
            URL.TabIndex = 6;
            URL.TextChanged += URL_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 36);
            label1.Name = "label1";
            label1.Size = new Size(44, 17);
            label1.TabIndex = 7;
            label1.Text = "速度：";
            // 
            // Speed
            // 
            Speed.Location = new Point(56, 36);
            Speed.Name = "Speed";
            Speed.Size = new Size(231, 17);
            Speed.TabIndex = 8;
            Speed.Text = "正在初始化...";
            Speed.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(17, 39);
            label5.Name = "label5";
            label5.Size = new Size(44, 17);
            label5.TabIndex = 9;
            label5.Text = "线程：";
            // 
            // Thread
            // 
            Thread.Location = new Point(67, 34);
            Thread.Maximum = new decimal(new int[] { int.MaxValue, 0, 0, 0 });
            Thread.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            Thread.Name = "Thread";
            Thread.Size = new Size(80, 23);
            Thread.TabIndex = 10;
            Thread.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(ThreadNow);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(Total);
            groupBox1.Controls.Add(Speed);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 75);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(293, 80);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "👀";
            // 
            // ThreadNow
            // 
            ThreadNow.Location = new Point(80, 53);
            ThreadNow.Name = "ThreadNow";
            ThreadNow.Size = new Size(207, 17);
            ThreadNow.TabIndex = 10;
            ThreadNow.Text = "正在初始化...";
            ThreadNow.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 53);
            label3.Name = "label3";
            label3.Size = new Size(68, 17);
            label3.TabIndex = 9;
            label3.Text = "当前线程：";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(URL);
            groupBox2.Location = new Point(12, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(629, 57);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "☑️";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 25);
            label4.Name = "label4";
            label4.Size = new Size(68, 17);
            label4.TabIndex = 11;
            label4.Text = "当前选择：";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(Stop);
            groupBox3.Controls.Add(Run);
            groupBox3.Controls.Add(Thread);
            groupBox3.Controls.Add(label5);
            groupBox3.Location = new Point(311, 75);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(330, 80);
            groupBox3.TabIndex = 13;
            groupBox3.TabStop = false;
            groupBox3.Text = "🕹";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(650, 165);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "Form1";
            Text = "流量消失器";
            ((System.ComponentModel.ISupportInitialize)Thread).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label label2;
        private Label Total;
        private Button Run;
        private Button Stop;
        private ComboBox URL;
        private Label label1;
        private Label Speed;
        private Label label5;
        private NumericUpDown Thread;
        private GroupBox groupBox1;
        private Label ThreadNow;
        private Label label3;
        private GroupBox groupBox2;
        private Label label4;
        private GroupBox groupBox3;
    }
}
