using System;
using System.Security.Policy;
using System.Text.Json;
using System.Timers;

namespace SimpleNetworkBomb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            byte[] bytes = new byte[8];
            fs.Position = 0;
            fs.Read(bytes, 0, bytes.Length);
            totaldownload = BitConverter.ToInt64(bytes);
            Total.Text = CountSize(totaldownload);
            if (File.Exists("URLs.txt"))
            {
                string[] URLs = File.ReadAllText("URLs.txt").Split("\r\n");
                if(URLs.Length == 0)
                {
                    MessageBox.Show("��Ҫ��URL����URLs.txt�ٴ�������");
                    Environment.Exit(-114514);
                }
                foreach(string URLstr in URLs)
                {
                    URL.Items.Add(URLstr);
                }
                firsturl = URLs[0];
                URL.Text = firsturl;
            }
            else
            {
                MessageBox.Show("��Ҫ��URL����URLs.txt�ٴ�������");
                Environment.Exit(-114514);
            }
            System.Timers.Timer timer = new System.Timers.Timer(1000); // ����ʱ����Ϊ1��
            timer.Elapsed += new ElapsedEventHandler(Method1);
            timer.AutoReset = true; // ����Ϊѭ��ִ��
            timer.Enabled = true; // ������ʱ��
        }
        public long totaldownload = 0;
        public bool iscancel = false;
        public byte[] buffer = new byte[1048576];
        public List<Task> tasks = new List<Task>();
        public int threadsnow = 0;
        public MemoryStream destinationStream = new MemoryStream();
        FileStream fs = new("Total.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
        public string firsturl = string.Empty;
        public async Task Download(string fileUrl)
        {
            threadsnow++;
            while (!iscancel)
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0");
                    HttpResponseMessage response = await client.GetAsync(fileUrl, HttpCompletionOption.ResponseHeadersRead);
                    using (Stream contentStream = await response.Content.ReadAsStreamAsync())
                    {
                        int bytesRead;
                        while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                        {
                            destinationStream.Seek(0, SeekOrigin.Begin);
                            await destinationStream.WriteAsync(buffer, 0, bytesRead);
                            totaldownload += bytesRead;
                            Total.Text = CountSize(totaldownload);
                            if (iscancel)
                            {
                                threadsnow--;
                                Save();
                                throw new Exception("$Canceled");
                            }
                        }
                    }
                }
                break;
            }
            threadsnow--;
            Save();
            return;
        }
        public static string CountSize(long Size)
        {
            string m_strSize = "";
            long FactSize = Size;
            if (FactSize < 1073741824)
                m_strSize = (FactSize / 1024.00 / 1024.00).ToString("F2") + " MB";
            else if (FactSize >= 1073741824)
                m_strSize = (FactSize / 1024.00 / 1024.00 / 1024.00).ToString("F2") + " GB";
            return m_strSize;
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            Run.Enabled = false;
            iscancel = false;
        Label1:
            try
            {
                tasks.Clear();
                for (int i = 0; i < Thread.Value; i++)
                {
                    tasks.Add(Download(URL.Text));
                }
                await Task.WhenAll(tasks);
                goto Label1;

            }
            catch (Exception ex)
            {
                if (ex.Message == "$Canceled")
                {
                    Run.Enabled = true;
                    return;
                }
                else
                {
                    threadsnow = 0;
                    goto Label1;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            iscancel = true;
            Run.Enabled = true;
        }
        void Method1(object source, ElapsedEventArgs e)
        {
            KeyValuePair<DateTime, long> t1 = new(DateTime.Now, totaldownload);
            System.Threading.Thread.Sleep(1000);
            KeyValuePair<DateTime, long> t2 = new(DateTime.Now, totaldownload);
            long s = t2.Value - t1.Value;
            TimeSpan t = t2.Key - t1.Key;
            long v = s / t.Seconds;
            Speed.Text = CountSize(v) + "/s";
            ThreadNow.Text = threadsnow.ToString();
        }
        public async void Save()
        {
            fs.Position = 0;
            await fs.WriteAsync(BitConverter.GetBytes(totaldownload));
        }

        private void URL_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
